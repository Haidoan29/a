﻿using System.ComponentModel.DataAnnotations;

namespace BtvnB7.Models
{
    public class HoaDon : Base
    {
        
        public int CodeSanPham { get; set; }
        public DateTime NgayXuat { get; set; }
        public string SDT { get; set; }


        public virtual ICollection<SanPham>? SanPhams { get; set; }
    }
}
