﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BtvnB7.Models
{
    public class ChiTietHoaDon : Base
    {
        
        public int IdHoaDon { get; set; }
        public int IdSanPham { get; set; }
        public decimal GiaBan { get; set; }
        public int SoLuong { get; set; }

        [ForeignKey("IdHoaDon")]
        public virtual HoaDon? GetHoaDons { get; set; }
    }
}
