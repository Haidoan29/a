﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BtvnB7.Models
{
    public class SanPham : Base
    {
        public string TenSanPham { get; set; }
        public decimal Gia { get; set; }
        public string Avatar { get; set; }

        public int HoaDonId { get; set; }

        [ForeignKey("HoaDonId")]
        public virtual HoaDon? GetHoaDon { get; set; }

    }
}
