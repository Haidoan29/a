﻿using BtvnB7.Data;
using BtvnB7.Models;

namespace BtvnB7.Repository
{
    public interface ISanPhamRepository
    {

    }
    public class SanPhamRepository : BaseRepository<SanPham>, ISanPhamRepository
    {
        public SanPhamRepository(ApplicationDbContext context) : base(context) { }
    }
}
