﻿using BtvnB7.Data;
using BtvnB7.Models;

namespace BtvnB7.Repository
{
    public interface IHoaDonRepository
    {

    }
    public class HoaDonRepository : BaseRepository<HoaDon>, IHoaDonRepository
    {
        public HoaDonRepository(ApplicationDbContext context) : base(context) { }
    }
}
