﻿using BtvnB7.Data;
using BtvnB7.Models;

namespace BtvnB7.Repository
{
    public interface IChiTietHoaDonRepository
    {

    }
    public class ChiTietHoaDonRepository : BaseRepository<ChiTietHoaDon>, IChiTietHoaDonRepository
    {
        public ChiTietHoaDonRepository(ApplicationDbContext context) : base(context) { }
    }
}
