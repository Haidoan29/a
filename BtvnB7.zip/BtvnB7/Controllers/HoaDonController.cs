﻿using BtvnB7.Models;
using BtvnB7.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BtvnB7.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HoaDonController : BaseController<HoaDon>
    {
        public HoaDonController(IBaseRepository<HoaDon> repository) : base(repository) { }
    }
}
