﻿using BtvnB7.Models;
using BtvnB7.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BtvnB7.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ChiTietHoaDonController : BaseController<ChiTietHoaDon>
    {
        public ChiTietHoaDonController(IBaseRepository<ChiTietHoaDon> repository) : base(repository) { }
    }
}
